from django.db import models

class RegistrationFormModel(models.Model):
    Email = models.EmailField(unique = True)
    Password = models.CharField(max_length=255)
    Confirm_Password = models.CharField(max_length=255)

