from django.urls import path
from . import views

urlpatterns = [
    path("Signup/", views.Signup, name='Signup'),
    path('activate/<uidb64>/<token>', views.activate, name='activate'),
]