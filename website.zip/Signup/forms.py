from django import forms

class RegistrationForm(forms.Form):
    email = forms.EmailField(max_length=255, widget=forms.EmailInput(attrs={'class': 'inputText', 'placeholder': 'Email'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'inputText', 'placeholder': 'Password (Password must be Strong or above)'}))
    confirm_password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'inputText', 'placeholder': 'Confirm Password'}))
    
    def __init__(self, *args, **kwargs):
        super(RegistrationForm, self).__init__(*args, **kwargs)
        self.fields['password'].widget.attrs['id'] = 'id_password'


    