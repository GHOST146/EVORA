from django.apps import AppConfig


class ChangepasswordConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ChangePassword'
