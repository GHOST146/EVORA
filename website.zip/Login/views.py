from django.shortcuts import render, redirect
from .forms import LoginForm
from django.contrib.auth import authenticate, login
from django.contrib import messages

def Login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            # Process form data to perform login
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            # Authenticate the user
            user = authenticate(request, username=email, password=password)
            if user is not None and user.is_active:
                # User is authenticated, log them in and redirect
                login(request, user)
                print(f"username: {email}, password: {password}")
                return redirect('Homepage')
            else:
                # Authentication failed, display error message
                messages.error(request, 'Invalid email or password.')
    else:
        form = LoginForm()
    return render(request,'Login/Login.html', {'form': form})