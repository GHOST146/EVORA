from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("Buydetails/<str:Id>", views.Buydetails, name = "Buydetails"),
]