from django.shortcuts import render, redirect
from Buy.models import Property
import joblib
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from Booking.forms import Bookingform 
from Booking.models import Bookingmodel
import os 
import matplotlib
matplotlib.use('agg')

# Get the directory of the current file
current_directory = os.path.dirname(os.path.abspath(__file__))

# Construct the path to the pickle file
file_path = os.path.join(current_directory, 'Forecaster.pkl')
file_path_scaler = os.path.join(current_directory, 'scaler.pkl')
file_path_PI = os.path.join(current_directory, 'PriceInsight.pkl')
file_path_scaler_PI = os.path.join(current_directory, 'PriceInsightScaler.pkl')
# Load the pickle file
model = joblib.load(file_path)
scaler = joblib.load(file_path_scaler)
modelPI = joblib.load(file_path_PI)
scalerPI = joblib.load(file_path_scaler_PI)


def Buydetails(request, Id):
    if request.method == "POST":  # Check if the form is submitted
        form = Bookingform(request.POST, request.FILES)
        if form.is_valid() and 'search-btn' in request.POST:
            queryset = Property.objects.get(id=Id)
            print('before')           
            if request.user.is_authenticated == False:
                print('test')
                return redirect('Login') 
            else:
                Bookingmodel.objects.create(date=form.cleaned_data['date'], email=request.user.email, address=queryset.address, image=queryset.image)
                print('after')
    
                return redirect('Buydetails', Id) 
               
    else:
        form = Bookingform()
    
    queryset = Property.objects.all()
    queryset = queryset.filter(id=Id)
    for obj in queryset:
        if obj.size != 0:
            obj.price_per_unit = round(obj.price / obj.size,2)
        else:
            obj.price_per_unit = None

    state = str(queryset[0].state)
    residence_type = str(queryset[0].residence_type)

    statemapping = {'Johor':0, 'Kedah':1, 'Kelantan':2, 'Kuala Lumpur':3, 'Melaka':4, 'Negeri Sembilan':5, 'Pahang':6, 'Perak':7, 'Perlis':8, 'Pulau Pinang':9, 'Sabah':10, 'Sarawak':11, 'Selangor':12, 'Terengganu':13}
    State = statemapping.get(state, -1)
    typemapping = {'Bungalow': 0, 'Apartment': 1, 'Condominium': 1, 'Terrace': 2}
    Type = typemapping.get(residence_type, -1)
    
    # Prepare new price data
    PriceNew = int(queryset[0].price)
    NOBedrooms = int(queryset[0].number_of_bedrooms)
    NOBathrooms = int(queryset[0].number_of_bathrooms)
    Size = int(queryset[0].size)

    # Create DataFrame for scaling
    new_pricearray = pd.DataFrame({'Price': [PriceNew]})
    print("newpricearray", new_pricearray)
    new_pricearrayPI = pd.DataFrame({'Rooms': [NOBedrooms], 'Bathrooms': [NOBathrooms], 'Size': [Size]})
    print(new_pricearrayPI)
    # Extract numeric columns for scaling
    numeric_columns = new_pricearray[['Price']]
    
    # Predict prices for the upcoming years
    years = np.array([2024, 2025, 2026, 2027, 2028]).reshape(-1, 1)
    new_price_scaled = scaler.transform(numeric_columns)
    predicted_prices = model.predict(new_price_scaled)
    print("newpricescaled", new_price_scaled)
    print("predictedprice", predicted_prices)
    new_pricearrayPI_scaled = scalerPI.transform(new_pricearrayPI)
    predicted_pricesPI = modelPI.predict(new_pricearrayPI_scaled)
    print("newpricescaledPI", new_pricearrayPI_scaled)
    print("predictedpricePI", predicted_pricesPI)
    
    # Flatten the predicted prices
    predprice = predicted_prices.flatten()

    # Create a plot
    plt.plot(years, predprice, label='predicted values', marker='o')
    plt.xlabel('X-axis label')
    plt.ylabel('Y-axis label')
    plt.title('Predicted prices of the property in 5 years')
    
    context = int(predicted_pricesPI)
    # Get the directory of the current file
    graph_directory = os.path.abspath("static/Images")
    print("graph directory:", graph_directory)

    # Save the plot as a PNG image
    plot_path = os.path.join(graph_directory, 'plot.png')
    plt.savefig(plot_path)

    # Close the plot to free up memory
    plt.close()

    # Pass the data to the template for rendering
    return render(request, 'BuyDetails/buy_detail.html', {'query': queryset, 'plot_path': plot_path , 'form': form, 'context': context})