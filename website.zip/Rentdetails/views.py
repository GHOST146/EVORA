from django.shortcuts import render, redirect
from Rent.models import Property
from Booking.forms import Bookingform
from Booking.models import Bookingmodel

def Rentdetails(request, Id):
    if request.method == "POST":  # Check if the form is submitted
        form = Bookingform(request.POST, request.FILES)
        if form.is_valid() and 'search-btn' in request.POST:
            queryset = Property.objects.get(id=Id)
            print('before')
            if request.user.is_authenticated == False:
                print('test')
                return redirect('Login') 
            else:
                Bookingmodel.objects.create(date=form.cleaned_data['date'], email=request.user.email, address=queryset.address, image=queryset.image)
                print('after')
                return redirect('Rentdetails', Id)
    else:
        form = Bookingform()
        print('before2')

    queryset = Property.objects.all()
    queryset = queryset.filter(id=Id)
    for obj in queryset:
        if obj.size != 0:
            obj.price_per_unit = round(obj.price / obj.size, 2)
        else:
            obj.price_per_unit = None
    return render(request, 'RentDetails/rent_detail.html', {'query': queryset, 'form': form})
