from django.db import models

class Property(models.Model):
    Id = models.PositiveIntegerField(primary_key = True, null=False)
    Name = models.CharField(max_length=255)
    Address = models.CharField(max_length=255)
    State = models.CharField(max_length=255)
    Owner = models.CharField(max_length = 255)
    Residence = models.CharField(max_length = 255)
    Bedrooms = models.PositiveIntegerField(default = 0)
    Bathrooms = models.PositiveIntegerField(default = 0)
    Size = models.PositiveIntegerField(default = 0)
    Price = models.PositiveIntegerField(default = 0)
    Image = models.ImageField(upload_to='property_images/', null=True)

    def __str__(self):
        return f"Name: {self.Name}, Address: {self.Address}, State: {self.State}, Owner: {self.Owner}, Residence: {self.Residence}, Bedrooms: {self.Bedrooms}, Bathrooms: {self.Bathrooms}, Size: {self.Size}, Price: {self.Price}, Image: {self.Image}"
