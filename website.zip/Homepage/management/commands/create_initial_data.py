from django.core.management.base import BaseCommand
from Buy.models import Property
import csv
import os

class Command(BaseCommand):
    help = 'Load initial property data into the database'

    def handle(self, *args, **options):
        csv_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'PropertyListings - Buy.csv')

        with open(csv_file_path, 'r') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                Property.objects.create(
                    property_name=row['PropertyName'],
                    residence_type=row['ResidenceType'],
                    tenure_type=row['TenureType'],
                    number_of_bedrooms=int(row['NumberOfBedrooms']),
                    number_of_bathrooms=int(row['NumberOfBathrooms']),
                    furnishing=row['Furnishing'],
                    extra_facilities=int(row['ExtraFacilities']),
                    size=float(row['Size']),
                    location_category=row['LocationCategory'],
                    address=row['Address'],
                    state=row['State'],
                    price=float(row['Price']),
                    image =row['Image'],
                    image2 = row['Image2'],
                    image3 = row['Image3']
                )
