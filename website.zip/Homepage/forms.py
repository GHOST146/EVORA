from django import forms

class PropertySearchFormBuy(forms.Form):
    search_text = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'searchtext',
            'placeholder': ' Search State..',
            'style': 'margin-top: 60px;'
        }),
        required=False,
    )

    property_type = forms.ChoiceField(
        choices=[
            ('All', 'All Residential'),
            ('Bungalow', 'Bungalow'),
            ('Apartment', 'Apartment'),
            ('Condominium', 'Condominium'),
            ('Terrace', 'Terrace'),
        ],
        widget=forms.Select(attrs={'style': 'margin-left: 50%'}),
        required=False
    )

    min_price = forms.ChoiceField(
        choices=[
            (0, 'Min. Price (RM)'),
            (1000, '1,000'),
            (100000, '100,000'),
            (200000, '200,000'),
            (300000, '300,000'),
            (500000, '500,000'),
            (750000, '750,000'),
            (1000000, '100,000,0'),
            (5000000, '500,000,0'),
        ],
        widget=forms.Select(attrs={'style': 'margin-left: 50%'}),
        required=False
    )

    max_price = forms.ChoiceField(
        choices=[
            (0, 'Max. Price (RM)'),
            (1000, '1,000'),
            (100000, '100,000'),
            (200000, '200,000'),
            (300000, '300,000'),
            (500000, '500,000'),
            (750000, '750,000'),
            (1000000, '100,000,0'),
            (5000000, '500,000,0'),
        ],
        widget=forms.Select(attrs={'style': 'margin-left: 50%'}),
        required=False
    )



    bedrooms = forms.ChoiceField(
        choices=[
            (0, 'Bedroom'),
            (1, '1'),
            (2, '2'),
            (3, '3'),
            (4, '4'),
            (5, '5+')
        ],
        widget=forms.Select(attrs={'style': 'margin-left: 50%'}),
        required=False
    )


class PropertySearchFormRent(forms.Form):
    search_text = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'searchtext',
            'placeholder': ' Search State..',
            'style': 'margin-top: 60px;'
        }),
        required=False
    )

    property_type = forms.ChoiceField(
        choices=[
            ('All', 'All Residential'),
            ('Bungalow', 'Bungalow/Villa'),
            ('Apartment', 'Apartment/Condo'),
            ('Semi-Detached', 'Semi-Detached'),
            ('Terrace', 'Terrace/Link'),
            ('Residential Land', 'Residential Land')
        ],
        widget=forms.Select(attrs={'style': 'margin-left: 50%'}),
        required=False
    )

    min_price = forms.ChoiceField(
        choices=[
            (0, 'Min. Price (RM)'),
            (500, '500'),
            (1000, '1,000'),
            (2000, '2,000'),
            (3000, '3,000'),
            (4000, '4,000'),
            (5000, '5,000'),
            (6000, '6,000'),
            (7000, '7,000'),
            (8000, '8,000'),
            (9000, '9,000'),
            (10000, '10,000')
        ],
        widget=forms.Select(attrs={'style': 'margin-left: 50%'}),
        required=False
    )

    max_price = forms.ChoiceField(
        choices=[
            (0, 'Max. Price (RM)'),
            (500, '500'),
            (1000, '1,000'),
            (2000, '2,000'),
            (3000, '3,000'),
            (4000, '4,000'),
            (5000, '5,000'),
            (6000, '6,000'),
            (7000, '7,000'),
            (8000, '8,000'),
            (9000, '9,000'),
            (10000, '10,000')
        ],
        widget=forms.Select(attrs={'style': 'margin-left: 50%'}),
        required=False
    )

    bedrooms = forms.ChoiceField(
        choices=[
            (0, 'Bedroom'),
            (1, '1'),
            (2, '2'),
            (3, '3'),
            (4, '4'),
            (5, '5+')
        ],
        widget=forms.Select(attrs={'style': 'margin-left: 50%'}),
        required=False
    )
