from django.shortcuts import render, redirect
from .forms import PropertySearchFormBuy, PropertySearchFormRent
from Buy.models import Property
from django.contrib.auth import logout
from random import sample

def Homebuy(request):
    if request.method == "POST":  # Check if the form is submitted
        form = PropertySearchFormBuy(request.POST, request.FILES)
        if form.is_valid() and 'search-btn' in request.POST:
            filter_params = form.cleaned_data.copy()
            if filter_params['search_text'] == "":
               filter_params['search_text'] = "None"
            return redirect('Buy',**filter_params)
    else:
        form = PropertySearchFormBuy()

    all_properties = Property.objects.all()
    
    # Randomly select 3 properties
    random_properties = sample(list(all_properties), min(3, len(all_properties)))
    
    # Separate the random properties into three separate variables
    property1, property2, property3 = random_properties[0], random_properties[1], random_properties[2]
    
    return render(request, 'Homepage2/home-buy.html', {'form': form, 'property1': property1, 'property2': property2, 'property3': property3})

def Homerent(request):
    if request.method == "POST":  # Check if the form is submitted
        form = PropertySearchFormRent(request.POST, request.FILES)
        if form.is_valid() and 'search-btn' in request.POST:
            filter_params = form.cleaned_data.copy()
            if filter_params['search_text'] == "":
               filter_params['search_text'] = "None"
            return redirect('Rent',**filter_params)
    else:
        form = PropertySearchFormRent()
    
    return render(request, 'Homepage2/home-rent.html', {'form': form})

def Logout(request):
    logout(request)
    previous_page = request.META.get('HTTP_REFERER')
    return redirect(previous_page)