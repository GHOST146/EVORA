from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("Rent/", views.Rent, name = "Rent"),
    path('Rent/<str:search_text>/<str:property_type>/<str:min_price>/<str:max_price>/<str:bedrooms>/', views.RentRequest, name='Rent'),
    
]
