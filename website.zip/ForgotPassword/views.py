from django.conf import settings
from django.contrib.auth.models import User
from django.core.mail import EmailMessage
from django.shortcuts import render
import random
import string
from django.template.loader import render_to_string
from django.contrib.sites.shortcuts import get_current_site

def ForgotPassword(request):
    if request.method == 'POST':
        email = request.POST.get('email') 
        
        # Generate a new password
        new_password = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
        
        # Update the user's password in the database
        try:
            user = User.objects.get(email=email)
            user.set_password(new_password)
            user.save()
            
            email_subject = "Password Reset Form!!"
            current_site = get_current_site(request)
            message = render_to_string('ChangePassword/PasswordReset.html',{
                'domain': current_site.domain,
                'Password' : new_password
            })
            email = EmailMessage(
            email_subject,
            message,
            settings.EMAIL_HOST_USER,
            [user.email],
            )
            email.fail_silently = True
            email.send()
            
            # Redirect to a page when new password has been sent
            return render(request, 'ForgotPassword/password_reset_sent.html')
        except User.DoesNotExist:
            # Handle when email doesn't exist in the database
            return render(request, 'ForgotPassword/password_reset_error.html')
    
    return render(request, 'ForgotPassword/ForgotPassword.html')
