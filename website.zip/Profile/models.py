from django.db import models


# Create your models here.
class Profilemodel(models.Model):
    Email = models.CharField(max_length = 100, unique = True)
    Firstname = models.CharField(max_length=100)
    Lastname = models.CharField(max_length=100)
    Nationality = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=100)
    Gender = models.CharField(max_length=100)
    Address = models.CharField(max_length=100)