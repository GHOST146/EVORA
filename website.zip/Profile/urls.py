from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('Profile/', views.Profile, name='Profile'),
    path('Editprofile/', views.Editprofile, name='Editprofile')
]
