from django import forms
from .models import Profilemodel

class Profileform(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(Profileform, self).__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.required = False

    class Meta:
        model = Profilemodel
        fields = ['Firstname', 'Lastname', 'Nationality', 'phone_number', 'Gender', 'Address']
        widgets = {
            'Address': forms.Textarea(attrs={'rows': 4, 'cols': 110}),  
        }