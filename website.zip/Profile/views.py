from django.shortcuts import render, redirect
from .forms import Profileform
from .models import Profilemodel

def Profile(request):
    user_profile = {}  # Initialize the user_profile variable

    if request.user.is_authenticated:
        try:
            # Check if a profile exists for the authenticated user
            user_profile = Profilemodel.objects.get(Email=request.user.email)
        except Profilemodel.DoesNotExist:
            # If no profile exists, populate default values
            user_profile["Firstname"] = "-"
            user_profile["Lastname"] = "-"
            user_profile["Nationality"] = "-"
            user_profile["Email"] = str(request.user.email) if request.user.email else "-"
            user_profile["phone_number"] = "-"
            user_profile["Gender"] = "-"
            user_profile["Address"] = "-"

    return render(request, 'Profile/Profile.html', {'users': user_profile})

def Editprofile(request):
    user_email = request.user.email
    try:
        profile = Profilemodel.objects.get(Email=user_email)
    except Profilemodel.DoesNotExist:
        profile = None

    if request.method == 'POST':
        form = Profileform(request.POST, instance=profile)
        if form.is_valid():
            if profile:
                form.save()  # Update existing profile
            else:
                profile = form.save(commit=False)
                profile.Email = user_email
                profile.save()  # Save new profile
            
            return redirect('Profile')  # Assuming 'Profile' is the name of the view to redirect to
    else:
        # If it's a GET request, populate the form with existing profile data if available
        form = Profileform(instance=profile)
    return render(request, 'Profile/ProfileEdit.html', {'form': form, 'email': user_email})